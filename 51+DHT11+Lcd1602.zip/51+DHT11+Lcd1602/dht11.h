#ifndef __aht11_h_
#define __aht11_h_
#include<reg51.h>

#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint 
#define uint unsigned int
#endif
sbit Temp_data=P1^0;



void DHT11_start();
unsigned char DHT11_rec_byte();
void DHT11_receive();
void DHT11_delay_us(unsigned char n);
void DHT11_delay_ms(unsigned int z);
